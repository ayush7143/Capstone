SELECT *, (`no of bed` + `no.of bathroom`) AS total_area
FROM table2
ORDER BY total_area DESC
LIMIT 3;
