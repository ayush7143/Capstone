SELECT `no of bed`, AVG(Area) AS avg_Area
FROM table2
GROUP BY `no of bed`;
