SELECT *
FROM table2
WHERE `no.of bathroom` > 1
AND `pets allowed` = 'Yes';

