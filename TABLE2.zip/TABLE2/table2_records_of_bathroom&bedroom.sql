SELECT `no of bed` AS num_bedrooms, `no.of bathroom` AS num_bathrooms, COUNT(*) AS record_count
FROM table2
GROUP BY `no of bed`, `no.of bathroom`;
