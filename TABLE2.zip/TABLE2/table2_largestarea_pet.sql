SELECT *
FROM table2
WHERE `pets allowed` = 'Yes'
ORDER BY Area DESC
LIMIT 1;
