select COUNT(*) as records from table3 where Roofdeck != 'Yes' and Storage != 'Yes' order by Sno desc;
