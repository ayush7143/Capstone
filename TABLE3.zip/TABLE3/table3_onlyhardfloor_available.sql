select * from table3 where `Hardwood floors` = 'Yes' and Roofdeck != 'Yes' and Storage != 'Yes' order by Sno desc;
