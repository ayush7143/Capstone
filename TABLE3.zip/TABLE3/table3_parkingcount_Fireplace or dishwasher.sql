select 
sum(CASE WHEN Parking = 'Yes' then 1 else 0 end) as Parking_count, 
sum( CASE WHEN Fireplace = 'Yes' or Dishwasher = 'Yes'  then 1 else 0 end) as Fireplace_or_dishwasher_count
from table3
where Parking = 'Yes' and (Fireplace = 'Yes' or Dishwasher = 'Yes');