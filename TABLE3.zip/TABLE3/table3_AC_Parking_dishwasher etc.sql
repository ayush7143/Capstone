select * from table3 where	(AC = 'Yes' and Parking = 'Yes' and Dishwasher = 'Yes'and fireplace = 'Yes')
order by Sno;