LOAD DATA INFILE "C:/ProgramData/MySQL/MySQL Server 8.2/Uploads/table1.csv"
INTO TABLE rentals
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(@discard, Address, City, Statecode, Country, RentalPrice, Deposit);

CREATE TABLE `rentals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Address` varchar(500) DEFAULT NULL,
  `City` varchar(500) DEFAULT NULL,
  `Statecode` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `RentalPrice` varchar(100) DEFAULT NULL,
  `Deposit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
)
