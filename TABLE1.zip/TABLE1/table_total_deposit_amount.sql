SELECT Country, COUNT(*) AS RecordCount, SUM(Deposit) AS TotalDeposit
FROM rentals
GROUP BY Country;
