SELECT Address, City, Deposit
FROM rentals
ORDER BY Deposit DESC
LIMIT 5;
