select	* from table1.rentals;
SELECT City, Statecode, AVG(RentalPrice) AS AverageRentalPrice
FROM table1.rentals
GROUP BY City, Statecode;

