SELECT *
FROM rentals
WHERE RentalPrice > (SELECT AVG(RentalPrice) FROM rentals);
