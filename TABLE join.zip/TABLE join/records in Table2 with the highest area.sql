SELECT table2.*, table3.*
FROM table2 table2
JOIN table3 table3 ON table2.Sno = table3.Sno
    where table2.Area = (
    SELECT MAX(Area)
    FROM table2
)
AND table3.Roofdeck = 'Yes';
