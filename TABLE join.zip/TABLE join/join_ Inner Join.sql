SELECT *
FROM table1
INNER JOIN table2 ON table1.Sno = table2.Sno;
