SELECT table2.*, table3.*
FROM table2 table2
JOIN table3 table3 ON table2.Sno = table3.Sno
WHERE table2.`no of bed` > 2
AND table3.AC = 'Yes';
