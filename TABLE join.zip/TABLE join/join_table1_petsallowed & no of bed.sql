SELECT *
FROM table1
WHERE Sno IN (
    SELECT Sno
    FROM table2
    WHERE `pets allowed` = 'YES' AND `no of bed` > 3
);


